package com.novo.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "proveedor")
public class Proveedor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int idprove;
	@Column
	private String nomprove;
	@Column
	private int ruc;
	@Column
	private String nomcontacto;
	@Column
	private String direccion;
	@Column
	private int telefono;

	public Proveedor() {		
	}

	public Proveedor(int idprove, String nomprove, int ruc, String nomcontacto, String direccion, int telefono) {
		super();
		this.idprove = idprove;
		this.nomprove = nomprove;
		this.ruc = ruc;
		this.nomcontacto = nomcontacto;
		this.direccion = direccion;
		this.telefono = telefono;
	}

	public int getIdprove() {
		return idprove;
	}

	public void setIdprove(int idprove) {
		this.idprove = idprove;
	}

	public String getNomprove() {
		return nomprove;
	}

	public void setNomprove(String nomprove) {
		this.nomprove = nomprove;
	}

	public int getRuc() {
		return ruc;
	}

	public void setRuc(int ruc) {
		this.ruc = ruc;
	}

	public String getNomcontacto() {
		return nomcontacto;
	}

	public void setNomcontacto(String nomcontacto) {
		this.nomcontacto = nomcontacto;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
	
	

}
