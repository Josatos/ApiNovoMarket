package com.novo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NovoMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
